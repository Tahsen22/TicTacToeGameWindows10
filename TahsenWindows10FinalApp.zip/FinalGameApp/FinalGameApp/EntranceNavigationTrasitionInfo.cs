﻿using Windows.UI.Xaml.Media.Animation;

namespace FinalGameApp
{
    internal class EntranceNavigationTrasitionInfo : NavigationTransitionInfo
    {
    }
}