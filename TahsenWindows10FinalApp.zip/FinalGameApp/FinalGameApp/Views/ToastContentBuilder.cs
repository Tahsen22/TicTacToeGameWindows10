﻿namespace FinalGameApp.Views
{
    internal class ToastContentBuilder
    {
        public ToastContentBuilder()
        {
        }
    }
}