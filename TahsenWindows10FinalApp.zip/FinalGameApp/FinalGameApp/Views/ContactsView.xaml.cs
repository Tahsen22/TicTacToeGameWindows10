﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.Email;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace FinalGameApp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ContactsView : Page
    {
        public ContactsView()
        {
            this.InitializeComponent();
        }
        string fullName, userEmail, msgsubject, msg;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            fullName = fname.Text;
            userEmail = email.Text;
            msgsubject = subject.Text;
            msg = message.Text;
            SendEmail();
            email.Visibility = Visibility.Collapsed;
            fname.Visibility = Visibility.Collapsed;
            subject.Visibility = Visibility.Collapsed;
            message.Visibility = Visibility.Collapsed;
            btn.Visibility = Visibility.Collapsed;

            thankmsg.Visibility = Visibility.Visible;
            thankmsg.Text = "Thank you " + fullName + " for contacting us!" + " " + "Your email address is " + userEmail + ".";
        }

        public async Task SendEmail()
        {
            EmailMessage email = new EmailMessage();
            email.To.Add(new EmailRecipient("tahsen.rashed@gmail.com"));
            string emailBody = "This is a message from the UWP app from " + fullName + "Email: " + userEmail + " regarding " + msgsubject + " Full message: " + msg;
            email.Body = emailBody;
            email.Subject = "UWP contact from " + fullName;
            await EmailManager.ShowComposeNewEmailAsync(email);
        }
    }
}
